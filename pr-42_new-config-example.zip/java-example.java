package com.arangodb.tinkerpop.gremlin.test;

import com.arangodb.tinkerpop.gremlin.utils.ArangoDBConfigurationBuilder;
import org.apache.commons.configuration.BaseConfiguration;
import org.apache.tinkerpop.gremlin.process.traversal.dsl.graph.GraphTraversalSource;
import org.apache.tinkerpop.gremlin.structure.Graph;
import org.apache.tinkerpop.gremlin.structure.Vertex;
import org.apache.tinkerpop.gremlin.structure.util.GraphFactory;
import org.junit.Test;

/**
 * This test is intended to test TinkerPop queries against ArangoDB
 */
public class TinkerPopTest {

  @Test
  public void testTinkerpop(){
    ArangoDBConfigurationBuilder builder = new ArangoDBConfigurationBuilder();
    builder.dataBase("knowledge_graph_platform");
    builder.graph("graph")
        .shouldPrefixCollectionNamesWithGraphName(false)
        .withVertexCollection("documents")
        .withVertexCollection("person")
        .withEdgeCollection("found_at")
        .configureEdge("found_at", "person", "document");

    builder.arangoHosts("localhost:8529")
     .arangoUser("root")
     .arangoPassword("Passw0rd");

    // create a ArangoDB graph
    BaseConfiguration conf = builder.build();
    Graph graph = GraphFactory.open(conf);
    GraphTraversalSource gts = new GraphTraversalSource(graph);

    // Clone to avoid setup time
    GraphTraversalSource g = gts.clone();
    
	//.V().hasLabel("person").value();
	//Vertex rv = g.V().has("name","marko").next();
    Vertex v2 = g.addV("person").property("name", "lop").property("lang", "java").next();

    // Add vertices
    /*Vertex v1 = g.addV("person").property(T.id, "1").property("name", "marko")
        .property("age", 29).next();
    g = gts.clone();
    Vertex v2 = g.addV("document").property(T.id, "3").property("name", "lop")
        .property("lang", "java").next();


    // Add edges
    g = gts.clone();
    Edge e1 = g.addE("found_at").from(v1).to(v2).property(T.id, "9")
        .property("weight", 0.4).next();

    // Graph traversal
    // Find "marko" in the graph
    g = gts.clone();
    Vertex rv = g.V().has("name","marko").next();
    assert v1 == rv;
    */
  }

}
